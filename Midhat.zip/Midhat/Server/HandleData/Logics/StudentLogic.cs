﻿using Cache.Lists;
using Repo.Repos;
using System.Collections.ObjectModel;

namespace Server.HandleData.Logics
{
    public class StudentLogic
    {
       
        public string AddStudent(Student StudentData)
        {
            var student = CacheData.Students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
            if (student != null)
            {
                Console.WriteLine("Student with this email already exists.");
                return "Student with this email already exists.";
            }

            CacheData.Students.Add(StudentData);

            return "Student has been Saved";

        }

        public string DeletingStudent(Student StudentData)
        {

            var student = CacheData.Students.Where(x => x.StudentEmail == StudentData.StudentEmail).FirstOrDefault();
            if (student != null)
            {
                CacheData.Students.Remove(student);
                Console.WriteLine("Student Deleted Successfully");

            }
            return "Student Deleted Successfully";

        }
        public ObservableCollection<Student> FethcingStudent()
        {
            return CacheData.Students;
        }
    }
}
