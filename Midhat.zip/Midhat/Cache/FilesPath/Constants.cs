﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cache.FilesPath
{
    public class Constants
    {
        public static string StudentFilePath = @"C:\Users\mhussain\source\repos\Uitilies\Files\StudentsData.xml";
        public static string TeacherFilePath = @"C:\Users\mhussain\source\repos\Uitilies\Files\TeachersData.xml";
        public static string UserFilePath = @"C:\Users\mhussain\source\repos\Uitilies\Files\UsersData.xml";
        public static string AnnouncementFilePath = @"C:\Users\mhussain\source\repos\Uitilies\Files\AnnouncementData.xml";
    }
}
