﻿using ComManager.CommunicationManager.ApplicatiosConnection;

namespace SchoolManagementServer {

    public class Program
    {
        public static void Main(string[] args)
        {
            MakingConnections makingConnection = new MakingConnections();
            makingConnection.Connection();

        }
    }

}
