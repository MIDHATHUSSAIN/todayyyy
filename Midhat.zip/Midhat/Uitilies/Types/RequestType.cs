﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uitilies.Types
{
    public enum RequestType
    {
        SignUp,
        SignIn,
        AddTeacher,
        DeleteTeacher,
        RetrievingTeacher,
        AddStudent,
        DeleteStudent,
        RetrievingStudent,
        AddAnnouncement,
        AddCourses,
        AddResult,
        AddAttendance,
        ViewAnnouncementT,
        ViewSubjects,
        ViewCourses,
        ViewAnnouncementS
    }
}
