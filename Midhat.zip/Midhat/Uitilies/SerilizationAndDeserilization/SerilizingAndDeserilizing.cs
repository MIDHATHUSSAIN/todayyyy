﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Uitilies.SerilizationAndDeserilization
{
    public class SerilizingAndDeserilizing
    {
        public static ObservableCollection<T> LoadData<T>(string path, string rootName)
        {
            try
            {
                var xRoot = new XmlRootAttribute
                {
                    ElementName = rootName,
                    IsNullable = true
                };
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<T>), xRoot);
                using (StreamReader reader = new StreamReader(path))
                {
                    return (ObservableCollection<T>)serializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                throw;
            }


        }

        public static void SaveData<T>(string path, ObservableCollection<T> Data,string rootName)
        {
            try
            {
                var xRoot = new XmlRootAttribute
                {
                    ElementName = rootName,
                    IsNullable = true
                };

                XmlSerializer userSerializer = new XmlSerializer(typeof(ObservableCollection<T>), xRoot);
                using (StreamWriter writer = new StreamWriter(path))
                {
                    userSerializer.Serialize(writer, Data);

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
        }

    }
}
