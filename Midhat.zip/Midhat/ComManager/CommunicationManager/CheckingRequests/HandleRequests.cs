﻿using Newtonsoft.Json;
using Repo.Repos;
using Server.HandleData.Logics;
using Uitilies.Types;

namespace ComManager.CommunicationManager.CheckingRequests
{
    public class HandleRequests
    {
        SignUpSignInLogic S = new SignUpSignInLogic();
        TeacherLogic Tl = new TeacherLogic();
        StudentLogic Sl = new StudentLogic();
        public string HandleSignupRequest(User UserData)
        {
            return S.SigningUp(UserData);
        }

        public string HandleSigninRequest(User UserData)
        {
            return S.SigningIn(UserData);
        }
        public string HandleAdminRequest(NetworkRequest request)
        {

            switch (request.Type)
            {
                case RequestType.AddTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return Tl.AddTeacher(teacher);
                    }

                case RequestType.DeleteTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return Tl.DeletingTeacher(teacher);
                    }
                case RequestType.RetrievingTeacher:
                    {
                        var teacher = JsonConvert.DeserializeObject<Teacher>(request.Payload);
                        return Tl.FethcingTeacher().ToString();
                    }
                default:
                    return "Admin: Action not supported";
            }
        }

        public string HandleTeacherRequest(NetworkRequest request)
        {
            switch (request.Type)
            {
                case RequestType.AddResult:
                    // Process result logic...
                    return "Result Added";
                case RequestType.AddAttendance:
                    return "dff";
                default:
                    return "Teacher: Action not supported";
            }
        }
        public string HandleStudentRequest(NetworkRequest request)
        {
            switch (request.Type)
            {
                case RequestType.AddStudent:
                    {
                        var studentData = JsonConvert.DeserializeObject<Student>(request.Payload);
                        return Sl.AddStudent(studentData);
                      
                    }
                case RequestType.DeleteStudent:
                    {
                        var students = Sl.FethcingStudent().ToString();
                        return JsonConvert.SerializeObject(students);
                    }
                case RequestType.RetrievingStudent:
                    {
                        var students = Sl.FethcingStudent().ToString();
                        return JsonConvert.SerializeObject(students);
                    }
                default:
                    return "Teacher: Action not supported";
            }
        }
    }
}
