﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repo.Repos
{
    public class Announcement
    {
        private string announcementDate;
        private string title;
        private string annoucement;
        private string forWhom;

        public string AnnouncementDate
        {
            get { return announcementDate; }
            set { announcementDate = value; }
        }

        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        public string Annoucementt
        {
            get { return annoucement; }
            set { annoucement = value; }
        }
        public string ForWhom
        {
            get { return forWhom; }
            set { forWhom = value; }
        }
    }
}
