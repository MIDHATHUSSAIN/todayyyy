﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SchoolMangement.Classes
{
    [XmlRoot("Users")]
    public class UserCollection
    {
        [XmlElement("User")]
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();
    }
}
