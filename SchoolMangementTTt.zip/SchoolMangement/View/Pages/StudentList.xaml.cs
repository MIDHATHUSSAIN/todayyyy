﻿using SchoolMangement.ViewModel;

namespace SchoolMangement.View.Pages
{

    public partial class StudentList 
    {
        public StudentList()
        {
            InitializeComponent();
            this.DataContext = new AddNewStudentViewModel();
        }
    }
}
