﻿using SchoolMangement.ViewModel;

namespace SchoolMangement.View.Pages
{
   
    public partial class AddNewStudent
    {
        public AddNewStudent()
        {
            InitializeComponent();
            this.DataContext = new AddNewStudentViewModel();
        }

        private void SaveButton_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}
