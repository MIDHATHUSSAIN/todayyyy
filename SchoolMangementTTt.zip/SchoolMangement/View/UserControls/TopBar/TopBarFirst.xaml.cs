﻿using SchoolMangement.Connection;

namespace SchoolMangement.View.UserControls.TopBar
{
  
    public partial class TopBarFirst
    {
        public string UserName { get; set; }
        public string UserRole { get; set; }
        public TopBarFirst()
        {
            InitializeComponent();
            if(AppSession.Instance.UserName == string.Empty)
            {
                UserName = $"User Name : Admin";
            }
            else
            {
                UserName = $"User Name : {AppSession.Instance.UserName}";
            }

               UserRole = $"Sign In : {AppSession.Instance.Role}";
             this.DataContext = this;
        }
    }
}
