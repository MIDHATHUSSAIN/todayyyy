﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using DevExpress.DataProcessing;
using Newtonsoft.Json;
using SchoolMangement.Classes;

namespace SchoolMangement.Connection
{
    public class MakingConnectionToServer
    {
        private static TcpClient client;   

        public static void MakingConnection()
        {
            try
            {
                int port = 5001;
                client = new TcpClient("127.0.0.1", port);
            }
            catch (Exception ex) { 
            
            }
           
        }

        public static async Task<string> SendingData(RequestType requestType, string requestRole, string requestPayload)
        {
            try
            {
                MakingConnection();
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("client is not coonected");
                    return "error";
                }

                NetworkStream stream = client.GetStream();
                var myRequest = new { Type = requestType.ToString(), Role = requestRole, Payload = requestPayload };
                string jsonRequest = JsonConvert.SerializeObject(myRequest);
                byte[] sendBuffer = Encoding.UTF8.GetBytes(jsonRequest);

                await stream.WriteAsync(sendBuffer, 0, sendBuffer.Length);

                // 2. Read the Response
                byte[] receiveBuffer = new byte[1024]; // Standard buffer size
                int bytesRead = await stream.ReadAsync(receiveBuffer, 0, receiveBuffer.Length);

                // 3. Convert bytes back to string
                string responseMessage = Encoding.UTF8.GetString(receiveBuffer, 0, bytesRead);

                return responseMessage;

            }
            catch(Exception ex)
            {
                throw;
            }
           
        }
    }
}
