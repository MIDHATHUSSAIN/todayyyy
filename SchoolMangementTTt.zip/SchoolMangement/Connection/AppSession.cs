﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolMangement.Connection
{
    public sealed class AppSession
    {
        private static readonly AppSession _instance = new AppSession();

        public static AppSession Instance
        {
            get { return _instance; }
        }
        private AppSession() { }
        public string UserName { get; set; }
        public string Role { get; set; }
       
    }
}
