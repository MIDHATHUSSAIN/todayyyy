﻿using SchoolMangement.Helper;
using SchoolMangement.View.Pages;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    public class TopBarViewModel : INotifyPropertyChanged
    {
        AddNewStudentViewModel dm = new AddNewStudentViewModel();

        private string _role;

        //For Admin
        public ICommand MoveToTeacher { get; }
        public ICommand MoveToStudent { get; }
        public ICommand MoveToAnnouncement { get; }
        public ICommand MoveToCourse { get; }

        //For Teacher
        public ICommand MoveToResult { get; }
        public ICommand MoveToViewSubjects { get; }
        public ICommand MoveToAttendance { get; }
        public ICommand MoveToViewAnnouncementT { get; }

        //For Student
        public ICommand MoveToViewResult { get; }
        public ICommand MoveToViewAttendance {  get; }
        public ICommand MoveToViewCourses { get; }

        private object _currentPage;
        private object _currentPageOfList;
        
        public bool IsAdmin => Role == "Admin";
        public bool IsTeacher => Role == "Teacher";
        public bool IsStudent => Role == "Student";
        public bool IsNotAdmin => !IsAdmin;
        public string Role
        {
            get => _role;
            set { 
                _role = value; OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public object CurrentPage
        {
            get => _currentPage;
            set { _currentPage = value; OnPropertyChanged(); }
        }
        public object CurrentPageOfList
        {
            get => _currentPageOfList;
            set { _currentPageOfList = value; OnPropertyChanged(); }
        }
        public TopBarViewModel()
        {
            MoveToTeacher = new RelayCommand(MovingToTeacher);
            MoveToStudent = new RelayCommand(MovingToStudent);
            MoveToAnnouncement = new RelayCommand(MovingToAnnouncement);
        }
        public void MovingToTeacher()
        {
            try
            {
                CurrentPage = new AddNewTeacher();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }  
        }

        public void MovingToAnnouncement()
        {
            CurrentPage = new AddNewAnnouncement();
            CurrentPageOfList = new StudentList();
            dm.RetrievingStudent();
            OnPropertyChanged();
        }


        public void MovingToStudent()
        {
            CurrentPage = new AddNewStudent();
            CurrentPageOfList = new StudentList();
            dm.RetrievingStudent();
            OnPropertyChanged();
        }
        private void OnPropertyChanged([CallerMemberName] string PropertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(PropertyName));
        }
    }
}
