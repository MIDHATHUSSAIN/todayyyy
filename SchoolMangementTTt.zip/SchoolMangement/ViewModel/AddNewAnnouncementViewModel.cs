﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Newtonsoft.Json;
using SchoolMangement.Classes;
using SchoolMangement.Connection;
using SchoolMangement.Helper;

namespace SchoolMangement.ViewModel
{
    public class AddNewAnnouncementViewModel
    {
        public ICommand AnnouncementSaveButton { get; }

        ObservableCollection<Announcement> _Announcement;
        public Announcement announcement = new Announcement();

        public AddNewAnnouncementViewModel()
        {
            AnnouncementSaveButton = new RelayCommand(SavingAnnouncement);

        }
        public async void SavingAnnouncement()
        {
            string PayLoad = JsonConvert.SerializeObject(announcement);
            string response = await MakingConnectionToServer.SendingData(RequestType.AddAnnouncement, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }

        public async void DeletingAnnouncement()
        {
            string PayLoad = JsonConvert.SerializeObject(announcement);
            string response = await MakingConnectionToServer.SendingData(RequestType.DeleteAnnouncement, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }
        public async void RetrievingAnnouncement()
        {
            var response = await MakingConnectionToServer.SendingData(RequestType.ViewAnnouncement, AppSession.Instance.Role, "AnnouncementData");
            _Announcement = JsonConvert.DeserializeObject<ObservableCollection<Announcement>>(response);
        }


    }
}
