﻿using DevExpress.Internal;
using Newtonsoft.Json;
using SchoolMangement.Classes;
using SchoolMangement.Connection;
using SchoolMangement.Helper;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace SchoolMangement.ViewModel
{
    class AddNewStudentViewModel:INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged; 
        private void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        public ICommand StudentSaveButton { get; }

        ObservableCollection<Student> students;
        public ObservableCollection<Student> Students
        {
            get => students;
            set
            {
                students = value;
                OnPropertyChanged(nameof(Students));
            }
        }

        public Student StudentData { get; set; } = new Student();


        public AddNewStudentViewModel()
        {
          
            StudentSaveButton = new RelayCommand(SavingStudent);

        }

        public async void SavingStudent()
        {
            string PayLoad = JsonConvert.SerializeObject(StudentData);
            string response = await MakingConnectionToServer.SendingData(RequestType.AddStudent, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }
        
        public async void DeletingStudent()
        {
            string PayLoad = JsonConvert.SerializeObject(StudentData);
            string response = await MakingConnectionToServer.SendingData(RequestType.DeleteStudent, AppSession.Instance.Role, PayLoad);
            System.Windows.MessageBox.Show(response);
        }
        
        public async void RetrievingStudent()
        {
            string PayLoad = JsonConvert.SerializeObject(StudentData);
            var response = await MakingConnectionToServer.SendingData(RequestType.RetrievingStudent, AppSession.Instance.Role, PayLoad);
            Students = JsonConvert.DeserializeObject<ObservableCollection<Student>>(response);
        }


    }
}
